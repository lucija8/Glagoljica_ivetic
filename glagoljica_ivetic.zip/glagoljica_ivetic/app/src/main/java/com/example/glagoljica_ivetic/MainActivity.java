package com.example.glagoljica_ivetic;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import androidx.core.content.res.ResourcesCompat;

public class MainActivity extends AppCompatActivity {

    Button butt;
    EditText originalni;
    TextView prevedeno;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        butt = findViewById(R.id.prevedi);
        originalni = findViewById(R.id.og_tekst);
        prevedeno = findViewById(R.id.prijevod);

        onButtonClickListener();
    }
    public void onButtonClickListener() {
        butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Typeface typeface = ResourcesCompat.getFont(MainActivity.this, R.font.glagolica_missal);
                prevedeno.setTypeface(typeface);
                String tekst = originalni.getText().toString();
                prevedeno.setText(tekst);
            }
        });
    }
}